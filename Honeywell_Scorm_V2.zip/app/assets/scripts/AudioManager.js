function loadAudio(pageNum) {
  soundManager.stopAll();
  jarvisAudio = soundManager.createSound({
    url: '../app/assets/audio/m01_t01_p0'+pageNum+'.mp3',
    autoLoad: true,
    autoPlay: true,
    onload: function() {
      enableButtons();
	  
      $.getJSON( "../app/assets/data/transcript.json", function( data ) {
          $(".transcript-text-container").html(data.transcript[pageNum-1].text)
      });
    },
    onfinish: function() {
		//console.log('finished');
      jarvisAudio.unload();
      disableButtons();
      $(".start-button").removeClass("disabled");
		
      if(Number(pageNum) !== 9 ) {

        document.querySelector('.next-button').classList.add("blinker");
      }
    },
    whileplaying() {
      syncPageText(jarvisAudio.position);
	  //console.log(jarvisAudio.position);
    }
  });
}

function toggleSoundVolume() {
  jarvisAudio.toggleMute();
}

function togglePlayPuase() {
  if(jarvisAudio.playState !== 0)
   jarvisAudio.togglePause();
}

function toggleButtonState(e) {
  if (e) {
    e.currentTarget.classList.toggle('selected');
  }
}

function disableButtons() {
  if (document.getElementById('button-playPause'))
  document.getElementById('button-playPause').classList.add("disabled");
  if (document.getElementById('button-audio'))
  document.getElementById('button-audio').classList.add("disabled");
}

function enableButtons() {
  if (document.getElementById('button-playPause'))
  document.getElementById('button-playPause').classList.remove("disabled");
  if (document.getElementById('button-audio'))
  document.getElementById('button-audio').classList.remove("disabled");
}

function millisToMinutesAndSeconds(millis) {
  var minutes = Math.floor(millis / 60000);
  var seconds = ((millis % 60000) / 1000).toFixed(0);
  var s = ((minutes * 60) + parseInt(seconds));
  return s;
}

function pauseSound() {
   //alert("Sound paused");
  jarvisAudio.pause();
}

function changeFontSize() {
  if (document.querySelector('.text-1-large') !== null)
    document.querySelector('.text-1-large').style.fontSize = '1em';
}

function changeText(element) {
  $("."+element).hide();
}

function imageSwap(id) {
  $(".image-container"+id).hide();
}

function highlightElement(id) {
  $(".highlight-image"+(id-1)).removeClass("highlight")
  $(".highlight-image"+id).addClass("highlight")
}

function syncPageText(position) {
    $("#button-playPause").removeClass("selected");
  if (qPoints !== null && currentCuePointId != undefined) {
     var t = millisToMinutesAndSeconds(position);
     if (t == qPoints[currentCuePointId]) {
       if (document.querySelector('.sync'+(currentCuePointId+1))) {
         document.querySelector('.sync'+(currentCuePointId+1)).classList.remove('fadeOut');
         document.querySelector('.sync'+(currentCuePointId+1)).classList.add('fadeIn');
       }
       if(qPointsExecution && qPointsExecution[currentCuePointId])
       {
         eval(qPointsExecution[currentCuePointId]);
       }
       currentCuePointId++;
     }
   }
}

module.exports = {
  toggleSoundVolume,
  togglePlayPuase,
  loadAudio,
  toggleButtonState
}
